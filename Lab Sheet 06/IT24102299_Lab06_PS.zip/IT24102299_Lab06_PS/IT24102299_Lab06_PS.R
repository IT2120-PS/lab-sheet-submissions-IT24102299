setwd("C:\\Users\\admin\\Desktop\\IT24102299_Lab06_PS")

#Binomial Distribution
#Here, random variable X has binomial distribution with n=50 and p=0.85

#P(X>=47) = 1-P(X<47) = 1-P(X<=46)
1 - pbinom(46,50,0.85, lower.tail=TRUE)
#P(X>46) is same as P(X>=47)
pbinom(46,50,0.85, lower.tail=FALSE)

#Number of customer calls received in a given hour
#Poisson distribution
#Here, random variable X has poisson distribution with lambda=12
dpois(15, 12)