setwd("C:\\Users\\IT24102299\\Desktop\\IT24102299_Lab04_PS")

branch_data<-read.table("Exercise.txt", header = TRUE, sep = ",")
fix(branch_data)
attach(branch_data)

str(branch_data)

boxplot(branch_data$Sales, main ="Boxplot of Sales", ylab = "Sales",outline =TRUE, outpch =8,horizontal =TRUE)

# Getting only five number summary
summary(branch_data$Advertising)

# IQR for Advertising
IQR(branch_data$Advertising)

# Function to check the existence of outliers in a numeric vector
get.outliers <- function(z) {
  q1 <- quantile(z)[2]  
  q3 <- quantile(z)[4]  
  iqr <- q3 - q1        
  
  ub <- q3 + 1.5 * iqr   
  lb <- q1 - 1.5 * iqr   
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  
  # Identify and display outliers
  outliers <- z[z < lb | z > ub]
  print(paste("Outliers:", paste(sort(outliers), collapse = ", ")))
}

# Check for outliers in the 'Years' variable
get.outliers(branch_data$Years)

